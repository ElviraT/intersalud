<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Civil extends Model
{
    protected $table = 'estados_civiles';
    public $timestamps = false;
}
