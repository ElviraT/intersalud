<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class HistoricoP extends Model
{
   protected $table = 'historico_login_pacientes';
   public $timestamps = false;
}
