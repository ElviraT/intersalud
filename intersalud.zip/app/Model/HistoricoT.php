<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class HistoricoT extends Model
{
   protected $table = 'historico_login_trabajadores';
   public $timestamps = false;
}
