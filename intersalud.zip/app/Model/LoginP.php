<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LoginP extends Model
{
   protected $table = 'login_pacientes';
   public $timestamps = false;
}
