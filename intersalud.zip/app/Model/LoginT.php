<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LoginT extends Model
{
   protected $table = 'login_trabajadores';
   public $timestamps = false;
}
