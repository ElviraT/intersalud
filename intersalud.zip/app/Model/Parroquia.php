<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Parroquia extends Model
{
    protected $table = 'parroquias';
    public $timestamps = false;
}
