<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Seniat extends Model
{
   protected $table = 'datos_seniat';
   public $timestamps = false;
}
