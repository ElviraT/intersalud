<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StatusC extends Model
{
   protected $table = 'status_consultas';
   public $timestamps = false;
}
