<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StatusF extends Model
{
   protected $table = 'status_factura';
   public $timestamps = false;
}
