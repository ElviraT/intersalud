<!-- Fullcalendar -->
<link href="{{ asset('css/main.css')}}" rel="stylesheet" type="text/css" />
<!-- selectize -->
<link href="{{ asset('css/selectize.min.css')}}" rel="stylesheet" type="text/css" />
{{--datepicker --}}
 <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datetimepicker.min.css')}}">