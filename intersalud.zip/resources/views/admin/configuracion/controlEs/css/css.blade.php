<!-- Select2 -->
<link href="{{ asset('css/selectize.min.css')}}" rel="stylesheet" type="text/css" />