{{--datepicker --}}
 <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datepicker.min.css')}}">

<!-- selectize -->
<link href="{{ asset('css/selectize.min.css')}}" rel="stylesheet" type="text/css" />

<style type="text/css">
  .nav-tabs .nav-link.active {
    font-weight:bold;
    background-color: transparent;
    border-bottom:3px solid #dd0000;
    border-right: none;
    border-left: none;
    border-top: none;
}
</style>