<!-- Fullcalendar -->
<link href="{{ asset('css/main.css')}}" rel="stylesheet" type="text/css" />
{{--datepicker --}}
 <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datetimepicker.min.css')}}">
<!-- Select2 -->
<link href="{{ asset('css/selectize.min.css')}}" rel="stylesheet" type="text/css" />

<style type="text/css">
  .nav-tabs .nav-link.active {
    font-weight:bold;
    background-color: transparent;
    border-bottom:3px solid #dd0000;
    border-right: none;
    border-left: none;
    border-top: none;
}

input.text {
   border: none; 
   font-size: 20px;
   font-weight: bold;
   padding: 5px;
}
.fc .fc-non-business{
  background: #FADBD8 !important;
} 
.fc-event{
    cursor: pointer;
}
</style>