{{--datepicker --}}
 <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datetimepicker.min.css')}}">
 <!--Toggle-->
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap4-toggle.min.css')}}">

<!-- Select2 -->
<link href="{{ asset('css/select2.min.css')}}" rel="stylesheet" type="text/css" />

<style type="text/css"></style>