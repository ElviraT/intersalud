{{--datepicker --}}
 <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datetimepicker.min.css')}}">
 {{--nuevo timepicker--}}
 <!--Toggle-->
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap4-toggle.min.css')}}">

<!-- selectize -->
<link href="{{ asset('css/selectize.min.css')}}" rel="stylesheet" type="text/css" />

<style type="text/css"></style>