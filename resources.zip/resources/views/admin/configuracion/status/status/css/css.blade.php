
 <style type="text/css">
 	input[type="color"] {
	-webkit-appearance: none;
	border:  solid 1px #000000 !important;
	width: 55px;
	height: 50px;
	}
	input[type="color"]::-webkit-color-swatch-wrapper {
		padding: 0;
	}
	input[type="color"]::-webkit-color-swatch {
		border: solid 1px  #000000 !important;
	}
 </style>