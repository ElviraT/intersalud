<div class="col-md-12">
	<div class="row">
		<div class="col-md-12 table-responsive">
			<table id="myTable" class="table table-striped table-bordered" width="100%">
			</table>
		</div>
	</div>
</div>