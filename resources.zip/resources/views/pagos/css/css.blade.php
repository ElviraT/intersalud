<!-- Select2 -->
<link href="{{ asset('css/selectize.min.css')}}" rel="stylesheet" type="text/css" />
{{--datepicker --}}
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datepicker.min.css')}}">
{{--fileinput--}}
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-icons.min.css')}}">
 
<!-- the fileinput plugin styling CSS file -->
<link rel="stylesheet" type="text/css" href="{{ asset('css/fileinput.min.css')}}">
<style type="text/css">
 	.negacion{
 		color: red;
 	}
 </style>