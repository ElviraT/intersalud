<!-- Fullcalendar -->
<link href="{{ asset('css/main.css')}}" rel="stylesheet" type="text/css" />
<!-- Select2 -->
<link href="{{ asset('css/select2.min.css')}}" rel="stylesheet" type="text/css" />
{{--datepicker --}}
 <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datetimepicker.min.css')}}">

  <!--Toggle-->
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap4-toggle.min.css')}}">
<style type="text/css">
.fc .fc-non-business{
	background: #FADBD8 !important;
}	
.fc-event{
    cursor: pointer;
}
</style>